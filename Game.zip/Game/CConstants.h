#pragma once

enum UnitTypes { 
	Airplane	= 1,
	Tank		= 2,
	Ship		= 3,
	AntiAir		= 11,
	AntiTank	= 12,
	AntiBoat	= 13,
	Building	= 99
};
