#include "CUnitProperty.h"


CUnitProperty::CUnitProperty(int speed, int range, int probability)
{
	m_speed = speed;
	m_hitRange = range;
	m_hitProbability = probability;
}