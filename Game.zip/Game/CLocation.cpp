#include "CLocation.h"


CLocation::CLocation(int x, int y)
{
	m_locationX = x;
	m_locationY = y;
}

